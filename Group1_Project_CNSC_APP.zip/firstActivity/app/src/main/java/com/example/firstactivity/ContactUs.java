package com.example.firstactivity;


import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;

import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class ContactUs extends AppCompatActivity {
    ProgressDialog progressDialog;
    EditText phone_enter,message_enter;
    Button bttn_send;
    Button button2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_us);

        phone_enter = findViewById(R.id.phone_enter);
        message_enter = findViewById(R.id.message_enter);
        bttn_send = findViewById(R.id.bttn_send);
        button2 = findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                progressDialog = new ProgressDialog(ContactUs.this);
                progressDialog.show();
                progressDialog.setContentView(R.layout.progress_dialog);
                progressDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent
                );

                Intent intent = new Intent(ContactUs.this, Menu.class );
                startActivity(intent);
            }
        });

        bttn_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ContextCompat.checkSelfPermission(ContactUs.this
                        , Manifest.permission.SEND_SMS)
                        == PackageManager.PERMISSION_GRANTED) {
                    sendMessage();
                } else {

                    ActivityCompat.requestPermissions(ContactUs.this, new String[]{Manifest.permission.SEND_SMS},100);

                }
            }
        });


    }



    private void sendMessage() {
        String sPhone = phone_enter.getText().toString().trim();
        String sMessage = message_enter.getText().toString().trim();
        if (!sPhone.equals("") && !sMessage.equals("")) {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(sPhone, null, sMessage
                    , null, null);

            Toast.makeText(getApplicationContext(), "SMS sent successfully", Toast.LENGTH_LONG).show();
        }else {

            Toast.makeText(getApplicationContext(), "SMS not sent", Toast.LENGTH_SHORT).show();
        }


    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 100 && grantResults.length > 0 && grantResults[0]
                == PackageManager.PERMISSION_GRANTED) {
            sendMessage();
        }
        else{
            Toast.makeText(getApplicationContext(),"Permission Denied",Toast.LENGTH_SHORT).show();
        }
    }
    public void onBack(){
        progressDialog.dismiss();
    }
}