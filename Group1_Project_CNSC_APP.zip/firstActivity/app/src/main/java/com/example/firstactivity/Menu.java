package com.example.firstactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

public class Menu extends AppCompatActivity {
    Button gridtest;
    Button idButton;
    Button idButton2;
    Button button3;
    Button website;
    Button location;
    Button contactUs;
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_menu);
        website = findViewById(R.id.website);
        idButton = findViewById(R.id.idButton);
        idButton2 = findViewById(R.id.idButton2);
        button3 = findViewById(R.id.button3);
        gridtest= findViewById(R.id.gridtest);
        location= findViewById(R.id.location);
        contactUs = findViewById(R.id.contactUs);


        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alert("Dialog");
            }
        });

        location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Menu.this,CnscMap.class);
                startActivity(i);

            }
        });

        idButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                progressDialog = new ProgressDialog(Menu.this);
                progressDialog.show();
                progressDialog.setContentView(R.layout.progress_dialog);
                progressDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent
                );
                Intent i = new Intent(Menu.this,NextActivity.class);
                startActivity(i);


            }
        });
        contactUs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                progressDialog = new ProgressDialog(Menu.this);
                progressDialog.show();
                progressDialog.setContentView(R.layout.progress_dialog);
                progressDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent
                );
                Intent i = new Intent(Menu.this,ContactUs.class);
                startActivity(i);


            }
        });
        idButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                progressDialog = new ProgressDialog(Menu.this);
                progressDialog.show();
                progressDialog.setContentView(R.layout.progress_dialog);
                progressDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent
                );
                Intent i = new Intent(Menu.this,MainActivity2.class);
                startActivity(i);
            }
        });

        website.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                progressDialog = new ProgressDialog(Menu.this);
                progressDialog.show();
                progressDialog.setContentView(R.layout.progress_dialog);
                progressDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent
                );
                Intent i = new Intent(Menu.this,cnscwebsites.class);
                startActivity(i);
            }
        });

        gridtest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Menu.this,CnscGridView.class);
                startActivity(i);
            }
        });


    }
    public void alert(String message){
        AlertDialog dlg = new AlertDialog.Builder(Menu.this)
                .setTitle("                   Need Help?")

                .setMessage(" Contact Us on Facebook: Camarines Norte State College ")
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {

                        dialog.dismiss();
                    }
                })
                .create();
        dlg.show();
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.add(0,200,0,"red");
        menu.add(0,200,0,"Green");
        menu.add(0,200,0,"Blue");


    }

    public void onBack(){
        progressDialog.dismiss();
    }
}