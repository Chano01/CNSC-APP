package com.example.firstactivity;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.ViewSwitcher;

public class SwitcherActivity extends AppCompatActivity {

    Button b_prev, b_next;
    Button button2;
    int[] images = {R.drawable.image1,R.drawable.image2,R.drawable.image3,R.drawable.image4,
            R.drawable.image5,R.drawable.image6,R.drawable.image7,R.drawable.image8,R.drawable.image9,
            R.drawable.image10,R.drawable.image11,R.drawable.image12,R.drawable.image13,R.drawable.image14,
            R.drawable.image15,R.drawable.image16};
    int i = 0;
    ImageSwitcher imageSwitcher;
    Animation in,out,in2,out2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_switcher);

        imageSwitcher = (ImageSwitcher) findViewById(R.id.imageSwitcher);

        imageSwitcher.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                ImageView imageView = new ImageView(getApplicationContext());
                imageView.setScaleType(ImageView.ScaleType.FIT_XY);
                imageView.setLayoutParams(new ImageSwitcher.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT));
                return imageView;
            }
        });

        Animation in = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.in);
        Animation out = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.out);

        Animation in2 = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.in2);
        Animation out2 = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.out2);

        b_prev = (Button) findViewById(R.id.b_prev);
        b_next = (Button) findViewById(R.id.b_next);


        b_prev.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View view) {
                imageSwitcher.setInAnimation(in2);
                imageSwitcher.setInAnimation(out2);
                if(i>0){
                    i--;
                    imageSwitcher.setImageResource(images[i]);
                }
            }
        });

        b_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imageSwitcher.setInAnimation(in);
                imageSwitcher.setInAnimation(out);
                if(i<images.length -1 ){
                    i++;
                    imageSwitcher.setImageResource(images[i]);
                }
            }
        });

    }
}