package com.example.firstactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

public class cnscwebsites extends AppCompatActivity {
    ProgressDialog progressDialog;
    Button back;
    Button lms;
    Button appointment;
    Button elibraries;
    Button studServices;
    Button Schoolweb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_cnscwebsites);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cnscwebsites);
        Schoolweb = findViewById(R.id.Schoolweb);
        lms = findViewById(R.id.lms);
        back = findViewById(R.id.button2);
        appointment = findViewById(R.id.appointment);
        elibraries = findViewById(R.id.elibraries);
        studServices = findViewById(R.id.studServices);
        back.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                progressDialog = new ProgressDialog(cnscwebsites.this);
                progressDialog.show();
                progressDialog.setContentView(R.layout.progress_dialog);
                progressDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent
                );

                Intent intent = new Intent(cnscwebsites.this, Menu.class );
                startActivity(intent);
            }
        });
        Schoolweb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://cnsc.edu.ph/cnsc-website/index.php");


            }
        });
        lms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                gotoUrl("https://cnsc.edu.ph/olms2/login/index.php");


            }
        });
        appointment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("http://s2.cnsc.edu.ph:55463/oaf/pages/appointment/");


            }
        });
        elibraries.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://sites.google.com/view/cnsc-elibraries/home?fbclid=IwAR3GQJUBuF2GQFCVg2rR8T5uWfKMve5Gv2APAJpnGSryMm3mhmKpKtCN0T0");


            }
        });
        studServices.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("http://s2.cnsc.edu.ph:55463/ssp/View/Home/");



            }
        });


    }
    private void gotoUrl(String s){
        Uri uri = Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));
    }

    public void onBack(){
        progressDialog.dismiss();
    }
}
